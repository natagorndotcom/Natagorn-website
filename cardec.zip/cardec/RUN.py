import cv2
from ultralytics import YOLO

model = YOLO("yolo11n.pt")
cap = cv2.VideoCapture("ใส่วิดีโอ")
#จะใช้กล้องใส่ 0

car_list = ["car", "motorcycle", "bus"]

while True:
    ret, frame = cap.read()
    if not ret:
        break
    results = model(frame)
    result = results[0]
    boxes = result.boxes
    names = result.names
    count = 0

    for box in boxes:

        x1, y1, x2, y2 = box.xyxy[0].cpu().numpy()
        class_id = int(box.cls[0].item())
        label = names[class_id]

        if label not in car_list:
            continue
        if label == "car":
            color = (0, 255, 0)
        elif label == "motorcycle":
            color = (255, 0, 255)
        elif label == "bus":
            color = (0, 0, 255)
        count += 1

        cv2.rectangle(frame, (int(x1), int(y1)), (int(x2), int(y2)), color, 2)
        cv2.putText(frame, label, (int(x1), int(y1 - 5)), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
    cv2.putText(frame, "Car: " + str(count), (10, 25), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 0), 2)
    cv2.imshow("Car Detect", frame)

    if cv2.waitKey(1) & 0xFF == ord('W'):
        break

cap.release()
cv2.destroyAllWindows()